# BluMirror

🎯 ابزار گرافیکی تغییر میرور اوبونتو از طریق ترمینال با رابط کاربری تعاملی (gum)

## نصب سریع

```bash
bash <(curl -s https://raw.githubusercontent.com/YOUR_USERNAME/BluMirror/main/install.sh)
```

## اجرا

```bash
sudo /opt/BluMirror/switch.sh
```

## پشتیبانی از نسخه‌ها
- Ubuntu 24.04 (noble)
- Ubuntu 22.04 (jammy)
- نسخه‌های دیگر با تشخیص خودکار

## میرورها
- آروان
- شاتل
- رایان‌همراه
